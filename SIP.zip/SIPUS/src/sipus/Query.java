/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sipus;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Dimasnizer
 */
public interface Query {
     public void tampil(String sql, DefaultTableModel model, JTable tabelpinjam, JLabel jlabel4);
}
