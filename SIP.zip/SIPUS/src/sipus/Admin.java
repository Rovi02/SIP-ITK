package sipus;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import static sipus.Menu_user.bl;/*

/**
 *
 * @author Dimasnizer
 */
public class Admin extends Menu {

    @Override
    public void tampil(String sql, DefaultTableModel model, JTable tabelpinjam, JLabel jlabel4) {
        Object[] isikolom = {"KODE BUKU", "NAMA BUKU", "PENGARANG", "PENERBIT"};
        model = new DefaultTableModel(null, isikolom);
        tabelpinjam.setModel(model);
        try {
            Connection kon = new Konek().getKoneksi();
            Statement stat = kon.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while (hasil.next()) {
                String kodbuk = hasil.getString("Kode_buku");
                String buku = hasil.getString("Buku");
                String pengarang = hasil.getString("Pengarang");
                String penerbit = hasil.getString("Penerbit");
                String[] data = {kodbuk, buku, pengarang, penerbit};
                model.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Menu_user.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void tampil(DefaultTableModel model, String sql, JTable tabelpinjam) {
        Object[] isikolom = {"KODE PINJAM", "NAMA BUKU", "TANGGAL PINJAM", "USER"};
        model = new DefaultTableModel(null, isikolom);
        tabelpinjam.setModel(model);
        try {
            Connection kon = new Konek().getKoneksi();
            Statement stat = kon.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while (hasil.next()) {
                String kodpin = hasil.getString("Kode_pinjam");
                String kodbuk = hasil.getString("Buku");
                String tanggal = hasil.getString("tanggal_pinjam");
                String user = hasil.getString("Nama");
                String[] data = {kodpin, kodbuk, tanggal, user};
                model.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Menu_user.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void cari(DefaultTableModel model, JTable tabelpinjam, JTextField a) {
        Object[] isikolom = {"KODE PINJAM", "NAMA BUKU", "TANGGAL PINJAM", "USER"};
        model = new DefaultTableModel(null, isikolom);
        tabelpinjam.setModel(model);
        String sql = "SELECT Kode_pinjam, Buku, tanggal_pinjam, Nama FROM pinjam,sipus,buku WHERE pinjam.nim=sipus.Username AND pinjam.Kode_buku = buku.Kode_buku AND Nama='" + a.getText() + "'";
        try {
            Connection kon = new Konek().getKoneksi();
            Statement stat = kon.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            if (!hasil.next()) {
                JOptionPane.showMessageDialog(tabelpinjam, "Maaf Data Yang Anda Cari TIdak Ada");

            }
            while (hasil.next()) {
                String kodpin = hasil.getString("Kode_pinjam");
                String kodbuk = hasil.getString("Buku");
                String tanggal = hasil.getString("tanggal_pinjam");
                String user = hasil.getString("Nama");
                String[] data = {kodpin, kodbuk, tanggal, user};
                model.addRow(data);

            }
        } catch (SQLException ex) {
            Logger.getLogger(Menu_user.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
