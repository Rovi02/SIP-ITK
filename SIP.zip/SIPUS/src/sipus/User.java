package sipus;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import static sipus.Menu_user.bl;

public class User extends Menu {

    public class waktu {
        private String getWaktu() {
            DateFormat timeFormat = new SimpleDateFormat("mmss");
            Date date = new Date();
            return timeFormat.format(date);
        }
    }

    public void pinjam(Object buku, DefaultTableModel m, JLabel jLabel4, JTable tabelpinjam) {
        waktu wkt = new waktu();
        try {
            Connection kon = new Konek().getKoneksi();
            Statement stat = kon.createStatement();
            String sql = "select*from buku where Buku = '" + buku + "';";
            ResultSet hasil = stat.executeQuery(sql);
            String tanggal;

            Calendar kal = new GregorianCalendar();
            String tahun = String.valueOf(kal.get(Calendar.YEAR));
            String bulan = String.valueOf(kal.get(Calendar.MONTH) + 1);
            String hari = String.valueOf(kal.get(Calendar.DAY_OF_MONTH));
            tanggal = tahun + "-" + bulan + "-" + hari;

            boolean sud = false;
            while (hasil.next()) {
                String coba = hasil.getString("Kode_buku");
                String kodpin = "P" + wkt.getWaktu();
                String nim = Login.indeks;
                a.dicoba = kodpin;
                a.stat = "Telah meminjam Buku";
                a.tglpnjm = tanggal;
                for (int i = 0; i < bl.size(); i++) {
                    if (coba.equals(bl.get(i))) {
                        sud = true;
                    }
                }
                if (sud == false) {
                    bl.add(coba);
                    //Cek_status a = new Cek_status(Cek_status.nama,Cek_status.nim,Cek_status.stat,tanggal,"");
                    kon.createStatement().executeUpdate("insert into pinjam (Kode_pinjam,Kode_buku,NIM,tanggal_pinjam) values ('" + kodpin + "','" + coba + "','" + nim + "','" + tanggal + "');");
                    JOptionPane.showMessageDialog(null, "Kode Pinjam Anda : " + kodpin + "\n\nTanggal Pinjam Anda : " + tanggal, "Pesan", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Buku masih di pinjam", "Pesan", JOptionPane.INFORMATION_MESSAGE);

                }
            }

            kon.close();
            stat.close();
            tampil(sql, m, tabelpinjam, jLabel4);
        } catch (SQLException ex) {
            Logger.getLogger(Menu_user.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
