package sipus;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Konek {
    Connection koneksi;
    public Connection getKoneksi(){
        try{
            koneksi = DriverManager.getConnection("jdbc:mysql://localhost/table_sipus", "root", "");
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Koneksi Gagal");
        }
        return koneksi;
    }

    
}
