/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sipus;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.ComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import static sipus.Menu_user.bl;

/**
 *
 * @author Rovi
 */
public class Menu implements Query {
    cek a = new cek();
    @Override
    public void tampil(String sql, DefaultTableModel model, JTable tabelpinjam, JLabel jlabel4) {
        sql = "select*from pinjam;";
        Object[] isikolom = {"KODE PINJAM", "KODE BUKU", "TANGGAL PINJAM"};
        model = new DefaultTableModel(null, isikolom);
        tabelpinjam.setModel(model);
        try {
            Connection kon = new Konek().getKoneksi();
            Statement stat = kon.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while (hasil.next()) {
                String kodpin = hasil.getString("Kode_pinjam");
                String kodbuk = hasil.getString("Kode_buku");
                String tanggal = hasil.getString("tanggal_pinjam");
                String[] data = {kodpin, kodbuk, tanggal};
                model.addRow(data);
            }
            jlabel4.setText("" + model.getRowCount());
        } catch (SQLException ex) {
            Logger.getLogger(Menu_user.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void kembali(JTextField kode, String kd) {
        try {
            Connection con = new Konek().getKoneksi();
            Statement pnjm = con.createStatement();
            //Statement kemb = con.createStatement();
            ResultSet kod = pnjm.executeQuery(kd);

            String tanggal;
            ArrayList<String> bl = new ArrayList<>();
            Calendar kal = new GregorianCalendar();
            String tahun = String.valueOf(kal.get(Calendar.YEAR));
            String bulan = String.valueOf(kal.get(Calendar.MONTH) + 1);
            String hari = String.valueOf(kal.get(Calendar.DAY_OF_MONTH));
            tanggal = tahun + "-" + bulan + "-" + hari;

            String km = null;

            if (!kode.getText().equals("")) {
                while (kod.next()) {
                    km = kod.getString("Kode_pinjam");
                    String bk = kod.getString("Kode_kembali");
                    String lk = kod.getString("Kode_buku");
                    bl.add(km);
                    if (kode.getText().equals(km) && km.equals(bk)) {
                        JOptionPane.showMessageDialog(null, "Buku Sudah Dikembalikan");
                    } else if (kode.getText().equals(km) && !kode.getText().equals(bk)) {
                        String sql = "Update pinjam set Kode_kembali='" + kode.getText() + "', tanggal_kembali = '" + tanggal + "' where Kode_pinjam='" + kode.getText() + "';";
                        pnjm.executeUpdate(sql);
                        Menu_user.bl.remove(lk);
                        a.kembali = kode.getText();
                        a.stat = "Telah Mengembalikan Buku";
                        a.tglkmbl = tanggal;
                        //Cek_status a = new Cek_status(Cek_status.nama, Cek_status.nim, Cek_status.stat, Cek_status.tglpnjm, Cek_status.tglkmbl);
                        JOptionPane.showMessageDialog(null, "Buku Telah Dikembalikan" + "\n\nTanggal Mengembalikan Buku :" + tanggal, "Pesan", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                kod.close();
                Boolean cek = false;
                for (int i = 0; i < bl.size(); i++) {
                    if (kode.getText().equals(bl.get(i))) {
                        cek = true;
                    }
                }
                if (cek == false) {
                    JOptionPane.showMessageDialog(null, "Kode Tidak ditemukan Atau Kode Bukan Milik Anda", "Notifikasi", JOptionPane.INFORMATION_MESSAGE);

                }

            } else {
                JOptionPane.showMessageDialog(null, "Harus Diisi", "Pesan", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
        }
    }

}
